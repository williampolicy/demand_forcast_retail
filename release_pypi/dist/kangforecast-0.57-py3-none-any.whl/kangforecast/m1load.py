import pandas as pd

def m1load(filename):
    return pd.read_csv(filename)
