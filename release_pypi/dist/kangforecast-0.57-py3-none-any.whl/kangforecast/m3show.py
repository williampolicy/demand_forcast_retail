def m3show(dataframe):
    print(dataframe)

