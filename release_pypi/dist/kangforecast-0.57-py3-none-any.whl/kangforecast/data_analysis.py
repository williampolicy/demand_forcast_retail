def analyze(dataframe):
    return dataframe.mean()
