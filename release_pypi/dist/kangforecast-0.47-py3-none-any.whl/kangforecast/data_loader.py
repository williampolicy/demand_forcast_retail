import pandas as pd

def load_data(filename):
    return pd.read_csv(filename)
