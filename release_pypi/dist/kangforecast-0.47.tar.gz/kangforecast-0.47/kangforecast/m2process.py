def m2process(dataframe):
    return dataframe.mean().values[0]
