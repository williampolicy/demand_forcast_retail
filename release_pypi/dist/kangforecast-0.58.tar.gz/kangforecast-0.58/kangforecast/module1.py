# 文件路径: kangforecast/module1.py

def add(a, b):
    return a + b
